//
//  ViewController.swift
//  ZachRU3A1Q4
//
//  Created by Leysa on 2019-05-20.
//  Copyright © 2019 Zach Robinson. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func UpButton(_ sender: UIButton) {
        
    }
    
    @IBAction func LeftButton(_ sender: UIButton) {
        
    }
    
    @IBAction func RightButton(_ sender: UIButton) {
        
    }
    
    @IBAction func DownButton(_ sender: UIButton) {
        print("whatever")
    }
}

